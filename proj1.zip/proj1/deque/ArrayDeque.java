package deque;

public class ArrayDeque<T> {

    private T[] items;
    private int size;
    private int nextFirst;
    private int nextLast;

    // create an empty arraylist
    public ArrayDeque(){
        items = (T[]) new Object[8];
        size = 0;
        nextFirst = 0; // arbitrarily start from 0 and 1
        nextLast = 1;

    }
    // the second way of resize
    private void resize(int capacity){
        T[] a = (T[]) new Object[capacity];
        int current = (nextFirst + 1) % items.length;
        for (int i = 0; i < size; i++){
            a[i] = items[current];
            current = (current + 1) % items.length;
        }
        items = a;
        nextLast = size;
        nextFirst = capacity -1;

    }

    public void addFirst(T x){
        if(size == items.length){
            resize(items.length * 2);
        }
        items[nextFirst] = x;
        nextFirst = (nextFirst -1 + items.length) % items.length;
        size ++ ;
    }
    public void addLast(T x){
        if(size == items.length){
            resize(items.length * 2);
        }
        items[nextLast] = x;
        size ++;
        nextLast = (nextLast + 1) % items.length;

    }
    public boolean isEmpty(){
        return size == 0;
    }

    public int size(){
        return size;
    }
    // Removes and returns the first item at the front of the deque.
    public T removeFirst(){
        if(size == 0){
            return null;
        }
        nextFirst = (nextFirst + 1) % items.length;
        T item = items[nextFirst];
        items[nextFirst] = null;
        size --;

        return item;

        }
    // Removes and returns the last item at the front of the deque.
    public T removeLast(){
        if(size == 0){
            return null;
        }
        nextLast = (nextLast - 1) % items.length;
        T item = items[nextLast];
        items[nextLast] = null;
        size --;
        return item;
    }
    //  Gets the item at the given index, where 0 is the front, 1 is the next item, and so forth.
    //     If no such item exists, returns null. Must not alter the deque!
    public T get ( int index){
        if (index < 0 || index >= items.length){
            return null;
        }
        int realindex = (nextFirst + 1 + index) % items.length;
        return items[realindex];
    }


}
