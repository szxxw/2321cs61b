package deque;

import org.junit.Test;

import java.util.Comparator;

import static org.junit.Assert.*;
public class MaxArrayDequeTest{
    @Test
    public void returnMaxTest() {
        MaxArrayDeque<String> l1 = new MaxArrayDeque<>(new Comparator());
        l1.addFirst('a');
        l1.addLast('b');

        assertEquals('b', l1.max());
//        assertEquals('b', l1.max(Comparable<String>));
    }

}
