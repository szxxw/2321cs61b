package gh2;

public class GuitarHero {
}
